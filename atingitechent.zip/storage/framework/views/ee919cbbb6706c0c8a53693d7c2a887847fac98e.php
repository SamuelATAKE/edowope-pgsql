<?php $__env->startSection('content'); ?>

<!-- Portfolio -->
<section id="Portfolio" class="content">

    <!-- Container -->
    <div class="container portfolio-title">

      <!-- Section Title -->
      <div class="section-title">
        <h2>Liste des administrations</h2>
      </div>
      <!--/Section Title -->

    </div>
    <!-- Container -->

    <div class="portfolio-top"></div>

    <!-- Portfolio Plus Filters -->
    <div class="portfolio">

      <!-- Portfolio Filters -->
      <div id="filters" class="sixteen columns">
        <ul class="clearfix">
          <li><a id="all" href="#" data-filter="*" class="active">
            <h5>Toutes</h5>
            </a></li>
          <li><a class="" href="#" data-filter=".branding">
            <h5>Publique(s)</h5>
            </a></li>
          <li><a class="" href="#" data-filter=".design">
            <h5>Privée(s)</h5>
            </a></li>
          <li><a class="" href="#" data-filter=".photography">
            <h5>Education</h5>
            </a></li>
          
        </ul>
      </div>
      <!--/Portfolio Filters -->

      <!-- Portfolio Wrap -->
      <div class="isotope" style="position: relative; overflow: hidden; height: 480px;" id="portfolio-wrap">

        <!-- Portfolio Item With PrettyPhoto  -->
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1); width: 337px; opacity: 1;" class="portfolio-item one-four   videography isotope-item">
          <div class="portfolio-image"> <img src="<?php echo e(asset($service->logo)); ?>"  alt="Portfolio 1"> </div>
          <a title="Starbucks Coffee" rel="prettyPhoto[galname]" href="<?php echo e(asset($service->logo)); ?>">
          <div class="project-overlay">
            <div class="project-info">
              <div class="zoom-icon"></div>
              <h4 class="project-name"><?php echo e($service->nom); ?> </h4>
              <p class="project-categories"><?php echo e($service->email); ?></p>
              <form method="POST" action="<?php echo e(route('choose.service')); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('post'); ?>
                  <input type="hidden" name="service" value="<?php echo e($service->id); ?> " />
                  <button type="submit" class="btn btn-danger">Faire un dépôt</button>
                </form>
            </div>
          </div>
          </a>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <!--/Portfolio Item With PrettyPhoto  -->

        <!-- Portfolio Item Video Expander  -->
        
        <!--/Portfolio Item Video Expander  -->

        <!-- Portfolio Item Normal Expander -->
        
        <!--/Portfolio Item Normal Expander -->

        <!-- Portfolio Item FullScreen Expander -->
        
        <!-- Portfolio Item FullScreen Expander -->

        <!-- Portfolio Item FullScreen Expander -->
        
        <!--/Portfolio Item FullScreen Expander -->

        <!-- Portfolio Item Normal Expander -->
        
        <!--/Portfolio Item Normal Expander -->

        <!-- Portfolio Item External Project  -->
        

        <!-- Portfolio Item With PrettyPhoto  -->
        

      </div>
      <!--/Portfolio Wrap -->

    </div>
    <!--/Portfolio Plus Filters -->

    <div class="portfolio-bottom"></div>

    <!-- Project Page Holder-->
    
    <!--/Project Page Holder-->

  </section>
  <!--/Portfolio -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Programing\Laravel\atingitechent\resources\views/homepages/administrations.blade.php ENDPATH**/ ?>