<?php $__env->startSection('content'); ?>

<div class="col-lg-10 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Ajouter un memebre de l'administration</h4>
        <br/>
        
        <form class="forms-sample">
          <div class="form-group">
            <label for="exampleInputName1">Nom</label>
            <input type="text" class="form-control" id="exampleInputName1" placeholder="Nom">
          </div>
          <div class="form-group">
            <label for="exampleInputName1">Prénom(s)</label>
            <input type="text" class="form-control" id="exampleInputName1" placeholder="Prénom(s)">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail3">Adresse mail</label>
            <input type="email" class="form-control" id="exampleInputEmail3" placeholder="Adresse mail">
          </div>
          <div class="form-group">
            <label for="exampleInputPassword4">Mot de passe</label>
            <input type="password" class="form-control" id="exampleInputPassword4" placeholder="Définir un mot de passe de connexion">
          </div>
          <div class="form-group">
            <label for="exampleSelectGender">Genre</label>
            <select class="form-control" id="exampleSelectGender">
              <option>Masculin</option>
              <option>Féminin</option>
            </select>
          </div>
          <div class="form-group">
            <label for="exampleSelectGender">Administration</label>
            <select class="form-control" id="exampleSelectGender">
              <option>Ministère de l'éducation</option>
              <option>Ministère de la décentralisation</option>
              <option>Ministère de l'artisanat</option>
            </select>
        </div>
        <div class="form-group">
            <label for="exampleInputPassword4">Fonction</label>
            <input type="text" class="form-control" id="exampleInputPassword4" placeholder="Quel poste occupe ce membre?">
          </div>
          <button type="submit" class="btn btn-gradient-primary mr-2">Ajouter</button>
          <button class="btn btn-light">Retour</button>
        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Programing\Laravel\atingitechent\resources\views/admin/ajoutmembre.blade.php ENDPATH**/ ?>