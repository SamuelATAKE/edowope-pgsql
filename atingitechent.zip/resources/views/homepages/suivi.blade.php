@extends('layouts.default')

@section('content')
<br>
<br>
<br>
<br>
<div class="row">
    <div class="col-lg-2"></div>
    <div class="col-lg-8">
       <div class="progress">
            <div class="progress-bar bg-warning" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
        </div>
        <div class="row">
            <div class="col-lg-3">
                <div class="card">
                    <div class="card-body">
                        Dépôt
                    </div>

                </div>
            </div>
            <div class="col-lg-3">
                <div class="card">
                    <div class="card-body">
                        Lancé pour traitement
                    </div>

                </div>
            </div>
            <div class="col-lg-3">
                <div class="card">
                    <div class="card-body">
                        Traitement
                    </div>

                </div>
            </div>
            <div class="col-lg-3">
                <div class="card">
                    <div class="card-body">
                        Retrait disponible
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-2"></div>
</div>
<br>
<br>
<br>
<br>
<section class="twitter-feed"><!--twitter-feed-->
    <div class="container  animated fadeInDown delay-07s wow">
      <div class="bell"><span><i class="fa-bell"></i></span></div>
      <p> Le dossier est incomplet, il manque la légalisation de votre déclaration d'association</p>
      <span>Annonce du 08/12/2020 </span> </div>
  </section>

@endsection
