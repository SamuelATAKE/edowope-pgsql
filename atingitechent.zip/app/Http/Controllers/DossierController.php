<?php

namespace App\Http\Controllers;

use App\Dossier;
use Illuminate\Http\Request;

class DossierController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate([
            'nom' => 'required',
            'prenom' => 'required',
            'telephone' => 'required',
            'profession' => 'required',
            'genre' => 'required',
            'type' => 'required',
            'contenu' => 'required',
            'motif' => 'required'
        ]);

        $code = '';
        $char = '';
        $char1 = '';
        $char = request('nom');
        $char1 = request('prenom');
        $code .= $char[0];
        $code .= $char[1];
        $code .= date('Y-m-d');
        $code .= $char1[0];
        $code .= $char1[1];
        // dd('Well');
        $dossier = new Dossier();

        $dossier->nom = request('nom');
        $dossier->prenom = request('prenom');
        $dossier->email = request('email');
        $dossier->telephone = request('telephone');
        $dossier->profession = request('profession');
        $dossier->genre = request('genre');
        $dossier->type = request('type');
        $dossier->contenu = request('contenu');
        $dossier->motif = request('motif');
        $dossier->commentaire = request('commentaire');
        $dossier->code_depot = $code;
        $dossier->etat = '';
        $dossier->administration = session('service');
        // dd($dossier);
        $dossier->save();

        return redirect(route('home'))->with('code', $code);

    }

    public function chooseService(){
        session([
            'service' => request('service')
        ]);
        return redirect(route('home.formulaire'));
    }

    public function list(){
        $dossiers = Dossier::where('administration', session('user')->administration)->where('etat', '')->get();

        return view('admin.depot', compact('dossiers'));
    }

    public function traitlist(){
        $dossiers = Dossier::where('administration', session('user')->administration)->where('etat', 'traitements')->get();

        return view('admin.traitements', compact('dossiers'));
    }

    public function list_trait(){
        $dossiers = Dossier::where('administration', session('user')->administration)->where('etat', 'traitement')->get();

        return view('admin.traitement', compact('dossiers'));
    }

    public function retraitlist(){
        $dossiers = Dossier::where('administration', session('user')->administration)->where('etat', 'retrait')->get();

        return view('admin.retraits', compact('dossiers'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Dossier  $dossier
     * @return \Illuminate\Http\Response
     */
    public function show(Dossier $dossier)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Dossier  $dossier
     * @return \Illuminate\Http\Response
     */
    public function edit(Dossier $dossier)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Dossier  $dossier
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Dossier $dossier)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Dossier  $dossier
     * @return \Illuminate\Http\Response
     */
    public function destroy(Dossier $dossier)
    {
        //
    }
}
