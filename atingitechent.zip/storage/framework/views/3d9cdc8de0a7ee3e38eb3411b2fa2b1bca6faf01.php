<?php $__env->startSection('content'); ?>

<div class="main-panel">
    <div class="content-wrapper">
      <div class="row">
<div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Ajouter administrateur</h4>
        
        <form class="forms-sample" method="POST" action="<?php echo e(route('admin.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
          <div class="form-group">
            <label for="exampleInputName1">Nom</label>
            <input type="text" class="form-control" id="exampleInputName1" placeholder="Nom de l'administrateur" name="nom">
          </div>
          <div class="form-group">
            <label for="exampleInputName1">Prénom(s)</label>
            <input type="text" class="form-control" id="exampleInputName1" placeholder="Prénom(s) de l'administrateur" name="prenom">
          </div>
          <div class="form-group">
            <label for="exampleInputEmail3">Adresse mail</label>
            <input type="email" class="form-control" id="exampleInputEmail3" placeholder="Adresse mail de l'administrateur" name="email">
          </div>
          <div class="form-group">
            <label for="exampleInputPassword4">Mot de passe</label>
            <input type="password" class="form-control" id="exampleInputPassword4" placeholder="Mot de passe de l'administrateur" name="password">
          </div>
          <div class="form-group">
            <label for="exampleInputName1">Numéro de téléphone</label>
            <input type="tel" class="form-control" id="exampleInputName1" placeholder="Numéro de téléphone de l'administrateur" name="telephone">
          </div>
          <div class="form-group">
            <label for="exampleInputName1">Fonction</label>
            <input type="text" class="form-control" id="exampleInputName1" placeholder="Fonction de l'administrateur" name="fonction">
          </div>
          <div class="form-group">
            <label for="exampleSelectGender">Administration</label>
              <select class="form-control" id="exampleSelectGender" name="administration">
                  <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($service->id); ?>"><?php echo e($service->nom); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          <button type="submit" class="btn btn-primary me-2">Ajouter</button>
          <button class="btn btn-light">Retour</button>
        </form>
      </div>
    </div>
  </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Programing\Laravel\atingitechent\resources\views/superadmin/createadmin.blade.php ENDPATH**/ ?>