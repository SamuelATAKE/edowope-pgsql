<?php $__env->startSection('content'); ?>

<div class="col-lg-10 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Services administratifs</h4>
        
        <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th>
                  Logo
                </th>
                <th>
                  Nom du service
                </th>
                <th>
                  Nombre de dépôts
                </th>
                <th>
                  Nombre de dossiers en<br/> cours de traitement
                </th>
                <th>
                  Nombre de dossiers traités
                </th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="py-1">
                    <img src="superadmin/images/faces/face1.jpg" alt="image"/>
                    </td>
                    <td>
                    <?php echo e($service->nom); ?>

                    </td>
                    <td>
                    25
                    </td>
                    <td>
                    $ 77.99
                    </td>
                    <td>
                    May 15, 2015
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\@Sam\Programing\Laravel\atingitechent\resources\views/superadmin/services.blade.php ENDPATH**/ ?>